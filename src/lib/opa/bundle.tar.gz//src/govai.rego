package govai.policy

import data.govai.policy.allow

has_forbidden_topics if {
	some i
	input.message_topics[i] == data.forbidden_topics[_]
}
