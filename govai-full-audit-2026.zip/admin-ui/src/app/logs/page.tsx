'use client';

import { useEffect, useState } from 'react';
import axios from 'axios';
import { format } from 'date-fns';
import { FileWarning, CheckCircle2, AlertTriangle, Fingerprint, X, ExternalLink, Activity, Database, ShieldCheck } from 'lucide-react';
import { API_BASE } from '@/lib/api';

interface AuditLog {
    id: string;
    action: string;
    metadata: any;
    signature: string;
    created_at: string;
}

export default function LogsPage() {
    const [logs, setLogs] = useState<AuditLog[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);

    useEffect(() => {
        const fetchLogs = async () => {
            try {
                const response = await axios.get(`${API_BASE}/v1/admin/logs`);
                setLogs(response.data.logs);
            } catch (error) { console.error("Error fetching logs:", error); }
            finally { setLoading(false); }
        };
        fetchLogs();
    }, []);

    const getActionIcon = (action: string) => {
        switch (action) {
            case 'EXECUTION_SUCCESS': return <CheckCircle2 className="w-4 h-4 text-emerald-500" />;
            case 'POLICY_VIOLATION': return <AlertTriangle className="w-4 h-4 text-destructive" />;
            case 'EXECUTION_ERROR': return <FileWarning className="w-4 h-4 text-amber-500" />;
            default: return <Fingerprint className="w-4 h-4 text-indigo-400" />;
        }
    };

    const getActionStyles = (action: string) => {
        switch (action) {
            case 'EXECUTION_SUCCESS': return "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
            case 'POLICY_VIOLATION': return "bg-destructive/10 text-destructive border-destructive/20";
            case 'EXECUTION_ERROR': return "bg-amber-500/10 text-amber-500 border-amber-500/20";
            default: return "bg-indigo-500/10 text-indigo-400 border-indigo-500/20";
        }
    };

    return (
        <div className="flex-1 overflow-auto p-8 bg-[url('/grid.svg')] bg-cover bg-center bg-no-repeat relative">
            <div className="absolute inset-0 bg-background/90 backdrop-blur-3xl z-0" />
            <div className="max-w-7xl mx-auto space-y-6 relative z-10">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                    <div>
                        <h2 className="text-3xl font-black tracking-tight flex items-center gap-3 bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-emerald-600">
                            <Database className="w-8 h-8 text-emerald-500" />
                            Security Audit Logs
                        </h2>
                        <p className="text-muted-foreground mt-2 font-medium">
                            Registro transacional inalterável. Cada operação Gateway é assinada digitalmente com HMAC-SHA256 para assegurar a cadeia de custódia corporativa.
                        </p>
                    </div>
                    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-500 text-xs font-bold uppercase tracking-widest">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        Live RLS Partitioning
                    </div>
                </div>

                <div className="glass rounded-xl shadow-sm overflow-hidden flex flex-col h-[calc(100vh-220px)]">
                    <div className="px-6 py-4 border-b border-border/50 bg-secondary/20 flex justify-between items-center">
                        <h3 className="font-bold text-lg flex items-center gap-2">
                            <Activity className="w-5 h-5 text-indigo-400" />
                            Raw Gateway Telemetry
                        </h3>
                        <div className="text-xs font-mono text-muted-foreground">
                            {logs.length} transactions intercepted today
                        </div>
                    </div>
                    <div className="overflow-auto flex-1">
                        <table className="w-full text-sm text-left relative">
                            <thead className="text-xs text-muted-foreground bg-secondary/30 uppercase tracking-wider sticky top-0 z-10 backdrop-blur-md">
                                <tr>
                                    <th className="px-6 py-4 font-semibold">Timestamp (UTC)</th>
                                    <th className="px-6 py-4 font-semibold">Política / Gateway Action</th>
                                    <th className="px-6 py-4 font-semibold">Metadata / Reason</th>
                                    <th className="px-6 py-4 font-semibold text-right">Cryptographic Signature</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-border/50">
                                {loading ? (
                                    <tr><td colSpan={4} className="px-6 py-12 text-center text-muted-foreground animate-pulse font-medium">Loading immutable logs...</td></tr>
                                ) : logs.length === 0 ? (
                                    <tr><td colSpan={4} className="px-6 py-12 text-center text-muted-foreground font-medium">No activity recorded for this organization.</td></tr>
                                ) : (
                                    logs.map((log) => (
                                        <tr key={log.id}
                                            onClick={() => setSelectedLog(log)}
                                            className="hover:bg-secondary/30 transition-colors cursor-pointer group">
                                            <td className="px-6 py-4 whitespace-nowrap text-muted-foreground font-mono text-xs group-hover:text-foreground transition-colors">
                                                {format(new Date(log.created_at), 'yyyy-MM-dd HH:mm:ss')}
                                            </td>
                                            <td className="px-6 py-4">
                                                <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border tracking-wider uppercase ${getActionStyles(log.action)}`}>
                                                    {getActionIcon(log.action)}
                                                    {log.action.replace('_', ' ')}
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 font-mono text-xs truncate max-w-sm text-foreground/80 group-hover:text-emerald-400 transition-colors">
                                                {log.metadata?.reason || log.metadata?.input || "Detalhamento de Transação"}
                                            </td>
                                            <td className="px-6 py-4 font-mono text-xs text-right truncate max-w-[150px] text-muted-foreground opacity-70 group-hover:opacity-100" title={log.signature}>
                                                {log.signature.substring(0, 24)}...
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                    <div className="px-6 py-3 border-t border-border flex justify-between items-center text-xs text-muted-foreground/50 bg-secondary/10">
                        <span className="flex items-center gap-1 font-mono"><Fingerprint className="w-3 h-3" /> HMAC-SHA256 signature chain</span>
                        <span className="font-mono bg-background border border-border/50 px-2 py-1 rounded">Page 1 of 1</span>
                    </div>
                </div>
            </div>

            {/* DETAIL MODAL - SLIDE OVER OR CENTERED */}
            {selectedLog && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex justify-end animate-in fade-in duration-200" onClick={() => setSelectedLog(null)}>
                    <div className="bg-card/95 border-l border-border/50 shadow-2xl w-full max-w-2xl h-full overflow-auto animate-in slide-in-from-right duration-300 relative" onClick={(e) => e.stopPropagation()}>

                        <div className="flex items-center justify-between p-6 border-b border-border/50 sticky top-0 bg-card/80 backdrop-blur-md z-10">
                            <div>
                                <h3 className="font-bold text-xl flex items-center gap-2 text-foreground">
                                    <ExternalLink className="w-5 h-5 text-emerald-500" /> Detalhes da Auditoria
                                </h3>
                                <p className="text-xs text-muted-foreground mt-1 font-mono tracking-wider">Trace Inspection</p>
                            </div>
                            <button onClick={() => setSelectedLog(null)} className="p-2 bg-secondary rounded-full hover:bg-secondary/80 hover:text-white text-muted-foreground transition-colors">
                                <X className="w-5 h-5" />
                            </button>
                        </div>

                        <div className="p-8 space-y-8">
                            {/* Trace ID */}
                            <div className="space-y-2">
                                <label className="text-xs uppercase text-muted-foreground font-bold tracking-widest flex items-center gap-2">
                                    <Activity className="w-3 h-3" /> Transaction Trace ID
                                </label>
                                <p className="font-mono text-sm bg-background border border-border/50 rounded-lg px-4 py-3 select-all text-emerald-400 break-all">{selectedLog.metadata?.traceId || selectedLog.id}</p>
                            </div>

                            <div className="grid grid-cols-2 gap-6">
                                {/* Action */}
                                <div className="space-y-2">
                                    <label className="text-xs uppercase text-muted-foreground font-bold tracking-widest">Gateway Action</label>
                                    <div>
                                        <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold border mt-1 shadow-inner ${getActionStyles(selectedLog.action)}`}>
                                            {getActionIcon(selectedLog.action)} {selectedLog.action}
                                        </div>
                                    </div>
                                </div>

                                {/* Timestamp */}
                                <div className="space-y-2">
                                    <label className="text-xs uppercase text-muted-foreground font-bold tracking-widest">Timestamp</label>
                                    <p className="text-sm font-mono mt-2 bg-secondary/30 px-4 py-2 rounded-lg border border-border/30">{format(new Date(selectedLog.created_at), "dd/MM/yyyy • HH:mm:ss")}</p>
                                </div>
                            </div>

                            {/* Reason (violations) */}
                            {selectedLog.metadata?.reason && (
                                <div className="space-y-2">
                                    <label className="text-xs uppercase text-destructive font-bold tracking-widest flex items-center gap-2">
                                        <AlertTriangle className="w-4 h-4" /> Motivo do Bloqueio OPA
                                    </label>
                                    <div className="bg-destructive/10 border border-destructive/20 text-destructive-foreground rounded-lg px-5 py-4 font-medium flex gap-3 shadow-inner">
                                        <div className="mt-0.5"><ShieldCheck className="w-5 h-5 opacity-70" /></div>
                                        <p>{selectedLog.metadata.reason}</p>
                                    </div>
                                </div>
                            )}

                            {/* Input */}
                            {selectedLog.metadata?.input && (
                                <div className="space-y-2">
                                    <label className="text-xs uppercase text-muted-foreground font-bold tracking-widest">Prompt Injetado (Input)</label>
                                    <div className="text-sm bg-background border border-border/50 rounded-lg px-5 py-4 leading-relaxed font-mono shadow-inner text-foreground/80 break-words whitespace-pre-wrap">
                                        {selectedLog.metadata.input}
                                    </div>
                                </div>
                            )}

                            <hr className="border-border/50" />

                            {/* Full Signature */}
                            <div className="space-y-2">
                                <label className="text-xs uppercase text-indigo-400 font-bold tracking-widest flex items-center gap-2">
                                    <Fingerprint className="w-4 h-4" /> Cryptographic Signature (HMAC)
                                </label>
                                <p className="font-mono text-[11px] bg-background border border-indigo-500/20 text-indigo-400/80 rounded-lg px-4 py-3 break-all select-all shadow-inner">{selectedLog.signature}</p>
                            </div>

                            {/* Full JSON Metadata */}
                            <div className="space-y-2 pb-10">
                                <label className="text-xs uppercase text-muted-foreground font-bold tracking-widest">Raw Document Payload</label>
                                <pre className="text-xs bg-[#0c0c0e] border border-border/50 rounded-lg p-5 overflow-auto font-mono text-amber-500/80 shadow-inner">
                                    {JSON.stringify(selectedLog.metadata, null, 2)}
                                </pre>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
