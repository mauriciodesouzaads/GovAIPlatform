'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Activity, ShieldCheck, Coins, ArrowUpRight, ShieldAlert, CreditCard, Bot, Info } from 'lucide-react';
import axios from 'axios';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadialBarChart, RadialBar, PolarAngleAxis } from 'recharts';

import { API_BASE } from '@/lib/api';

interface DashboardStats {
  total_assistants: number;
  total_executions: number;
  total_violations: number;
  total_tokens?: number;
  estimated_cost_usd?: string;
  usage_history?: { name: string; requests: number; violations: number; }[];
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await axios.get(`${API_BASE}/v1/admin/stats`);
        setStats(response.data);
      } catch (error) {
        console.error("Error fetching stats:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const interceptionRate = stats && stats.total_executions > 0
    ? Math.round((stats.total_violations / stats.total_executions) * 100)
    : 0;

  return (
    <div className="flex-1 overflow-auto p-4 md:p-8 bg-black relative">
      <div className="absolute inset-0 bg-[url('/grid.svg')] bg-cover bg-center bg-no-repeat opacity-20 pointer-events-none" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-emerald-500/10 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto space-y-6 relative z-10 transition-all duration-500 ease-out">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h2 className="text-3xl font-black tracking-tight text-white flex items-center gap-3">
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-emerald-600">
                GovAI
              </span>
              Security Command Center
            </h2>
            <p className="text-muted-foreground mt-1.5 font-medium text-sm">
              Real-time telemetry, risk mitigation, and OPA governance overview.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
            <span className="text-xs font-bold text-emerald-500 tracking-wider uppercase">System Operational</span>
            <Link href="/reports" className="ml-4 bg-white/5 hover:bg-white/10 text-white border border-white/10 text-xs font-semibold px-4 py-2 rounded-full transition-all">
              Gerar PDF de Auditoria
            </Link>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 animate-pulse">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="h-32 bg-white/5 border border-white/10 rounded-2xl" />
            ))}
            <div className="col-span-1 md:col-span-3 h-[400px] bg-white/5 border border-white/10 rounded-2xl" />
            <div className="col-span-1 h-[400px] bg-white/5 border border-white/10 rounded-2xl" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">

            {/* 1. Bento Box: Executions (Standard) */}
            <div className="bg-[#111] border border-white/10 rounded-2xl p-5 hover:border-white/20 transition-all group flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                  <Activity className="h-5 w-5 text-emerald-400" />
                </div>
                <Link href="/logs" className="opacity-0 group-hover:opacity-100 transition-opacity text-xs bg-white/10 hover:bg-white/20 px-2 py-1 rounded text-white flex items-center gap-1">
                  Ver Logs <ArrowUpRight className="w-3 h-3" />
                </Link>
              </div>
              <div className="mt-4">
                <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider mb-1 flex items-center justify-between">
                  Processamento de IA
                  <span title="Volume total de prompts processados. Metrificação exigida para rastreabilidade de acessos (LGPD Art. 37)."><Info className="w-3.5 h-3.5 opacity-50 hover:opacity-100 cursor-help transition-opacity" /></span>
                </p>
                <div className="text-3xl font-black text-white">{stats?.total_executions.toLocaleString() || 0}</div>
                <p className="text-xs text-emerald-400/80 mt-1 font-medium bg-emerald-500/10 inline-block px-2 py-0.5 rounded">Calls processadas</p>
              </div>
            </div>

            {/* 2. Bento Box: Policy Violations (Highlighted/Danger) */}
            <div className="bg-gradient-to-br from-red-950/40 to-[#111] border border-red-500/20 rounded-2xl p-5 hover:border-red-500/40 transition-all group flex flex-col justify-between relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 blur-3xl pointer-events-none" />
              <div className="flex justify-between items-start relative z-10">
                <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center border border-red-500/20">
                  <ShieldAlert className="h-5 w-5 text-red-500" />
                </div>
                <Link href="/approvals" className="opacity-0 group-hover:opacity-100 transition-opacity text-xs bg-red-500/20 hover:bg-red-500/40 px-2 py-1 rounded text-red-200 border border-red-500/20 flex items-center gap-1">
                  Quarentena <ArrowUpRight className="w-3 h-3" />
                </Link>
              </div>
              <div className="mt-4 relative z-10">
                <p className="text-xs text-red-400/80 font-semibold uppercase tracking-wider mb-1 flex items-center justify-between">
                  Violações OPA Barradas
                  <span title="Incidentes de segurança mitigados automaticamente. Previne vazamento de PII (LGPD Art. 46) e ataques (BCB 4.557 Art. 21)."><Info className="w-3.5 h-3.5 opacity-60 hover:opacity-100 cursor-help text-red-300 transition-opacity" /></span>
                </p>
                <div className="text-3xl font-black text-white flex items-baseline gap-2">
                  {stats?.total_violations.toLocaleString() || 0}
                  <span className="text-sm font-medium text-red-400/60 bg-red-500/10 px-1.5 py-0.5 rounded">Bloqueios P0</span>
                </div>
              </div>
            </div>

            {/* 3. Bento Box: Tokens / Cost */}
            <div className="bg-[#111] border border-white/10 rounded-2xl p-5 hover:border-white/20 transition-all group flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <div className="w-10 h-10 rounded-xl bg-violet-500/10 flex items-center justify-center border border-violet-500/20">
                  <Coins className="h-5 w-5 text-violet-400" />
                </div>
              </div>
              <div className="mt-4">
                <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider mb-1">Consumo LLM</p>
                <div className="text-3xl font-black text-white">{stats?.total_tokens?.toLocaleString() || 0}</div>
                <p className="text-xs text-violet-400/80 mt-1 font-bold bg-violet-500/10 inline-flex items-center gap-1 px-2 py-0.5 rounded">
                  <CreditCard className="w-3 h-3" /> ≈ ${stats?.estimated_cost_usd || '0.00'}
                </p>
              </div>
            </div>

            {/* 4. Bento Box: Agents */}
            <div className="bg-[#111] border border-white/10 rounded-2xl p-5 hover:border-white/20 transition-all group flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center border border-blue-500/20">
                  <Bot className="h-5 w-5 text-blue-400" />
                </div>
                <Link href="/assistants" className="opacity-0 group-hover:opacity-100 transition-opacity text-xs bg-white/10 hover:bg-white/20 px-2 py-1 rounded text-white flex items-center gap-1">
                  Gerenciar <ArrowUpRight className="w-3 h-3" />
                </Link>
              </div>
              <div className="mt-4">
                <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider mb-1">Agentes de IA Ativos</p>
                <div className="text-3xl font-black text-white">{stats?.total_assistants.toLocaleString() || 0}</div>
                <p className="text-xs text-blue-400/80 mt-1 font-medium bg-blue-500/10 inline-block px-2 py-0.5 rounded">Modelos em Prod</p>
              </div>
            </div>

            {/* 5. Bento Box: Gateway Traffic Chart (Large) */}
            <div className="md:col-span-3 bg-[#111] border border-white/10 rounded-2xl p-6 hover:border-white/20 transition-all flex flex-col min-h-[400px]">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="font-bold text-white flex items-center gap-2 text-lg">
                    Gateway Telemetry
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">Tráfego limpo vs Requisições interceptadas no Edge.</p>
                </div>
                <div className="flex gap-4">
                  <div className="flex items-center gap-2 text-xs font-medium text-emerald-400"><span className="w-2 h-2 rounded bg-emerald-500"></span> Clean</div>
                  <div className="flex items-center gap-2 text-xs font-medium text-red-500"><span className="w-2 h-2 rounded bg-red-500"></span> OPA Block</div>
                </div>
              </div>

              <div className="flex-1 w-full relative">
                {stats?.usage_history ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={stats.usage_history} margin={{ top: 5, right: 0, bottom: 0, left: -25 }}>
                      <defs>
                        <linearGradient id="colorRequests" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="colorViolations" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#ef4444" stopOpacity={0.4} />
                          <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} opacity={0.5} />
                      <XAxis dataKey="name" stroke="#666" fontSize={11} tickLine={false} axisLine={false} dy={10} />
                      <YAxis stroke="#666" fontSize={11} tickLine={false} axisLine={false} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#111', borderColor: '#333', borderRadius: '12px', color: '#fff', padding: '12px', boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.5)' }}
                        itemStyle={{ fontWeight: 600 }}
                        cursor={{ stroke: '#555', strokeWidth: 1, strokeDasharray: '4 4' }}
                      />
                      <Area type="monotone" name="Clean Executions" dataKey="requests" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorRequests)" activeDot={{ r: 6, strokeWidth: 0, fill: '#10b981' }} />
                      <Area type="monotone" name="Policy Blocks" dataKey="violations" stroke="#ef4444" strokeWidth={3} fillOpacity={1} fill="url(#colorViolations)" activeDot={{ r: 6, strokeWidth: 0, fill: '#ef4444' }} />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="absolute inset-0 bg-[#161616] animate-pulse rounded-lg border border-white/5" />
                )}
              </div>
            </div>

            {/* 6. Bento Box: Protection Gauge (Vertical layout) */}
            <div className="bg-[#111] border border-white/10 rounded-2xl p-6 hover:border-white/20 transition-all flex flex-col min-h-[400px] relative overflow-hidden group">
              <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-emerald-950/40 to-transparent pointer-events-none" />

              <div className="mb-4">
                <h3 className="font-bold text-white text-lg flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-400" />
                    Protection Rate
                  </div>
                  <span title="Índice de Eficácia de Controles (IEC). Demonstração matemática de prevenção exigida pela Resolução BCB 4.557 de Gerenciamento de Risco Cibernético."><Info className="w-4 h-4 opacity-50 hover:opacity-100 cursor-help transition-opacity" /></span>
                </h3>
                <p className="text-xs text-muted-foreground mt-1 leading-relaxed">Impacto do motor OPA + DLP em tempo real.</p>
              </div>

              <div className="flex-1 w-full flex flex-col items-center justify-center relative z-10 pt-4">
                {stats ? (
                  <div className="relative w-48 h-48 flex items-center justify-center">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadialBarChart
                        cx="50%" cy="50%"
                        innerRadius="70%" outerRadius="100%"
                        barSize={12}
                        data={[{ name: 'Rate', value: interceptionRate, fill: interceptionRate > 5 ? '#ef4444' : '#10b981' }]}
                        startAngle={90} endAngle={-270}
                      >
                        <PolarAngleAxis type="number" domain={[0, 100]} angleAxisId={0} tick={false} />
                        <RadialBar background={{ fill: '#222' }} dataKey="value" cornerRadius={10} />
                      </RadialBarChart>
                    </ResponsiveContainer>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className={`text-4xl font-black ${interceptionRate > 5 ? 'text-red-500' : 'text-emerald-400'}`}>
                        {interceptionRate}%
                      </span>
                      <span className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest mt-1">Interceptado</span>
                    </div>
                  </div>
                ) : (
                  <div className="w-40 h-40 rounded-full border-[8px] border-[#222] animate-pulse" />
                )}

                {stats && (
                  <div className="mt-8 text-center bg-[#161616] border border-white/5 rounded-xl p-4 w-full">
                    <p className="text-sm text-gray-300 font-medium leading-tight">
                      <span className="text-red-400 font-bold">{stats.total_violations}</span> incidentes isolados de um total de <span className="text-white font-bold">{stats.total_executions}</span> transações.
                    </p>
                  </div>
                )}
              </div>
            </div>

          </div>
        )}
      </div>
    </div>
  );
}
