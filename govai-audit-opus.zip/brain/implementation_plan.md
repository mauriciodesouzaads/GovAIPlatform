# Alinhamento Final de Testes E2E (Sprint 8)

Este plano descreve os ajustes realizados para garantir que a esteira CI/CD da GovAI Platform execute com 100% de sucesso, com foco especial na Phase 2 (Autenticação) e Phase 4 (Governança).

## Proposed Changes

### [Backend] Consistência de Autenticação e Seed

#### [MODIFY] [admin.routes.ts](file:///Users/mauriciodesouza/Desktop/TRABALHO/GovAI%20-%20Enterprise%20AI%20GRC%20/GitHub%20/GovAIPlatform/src/routes/admin.routes.ts)
- Implementação de verificação estrita da flag `requires_password_change`.
- Retorno mandatório de **403 Forbidden** com `resetToken` para o primeiro login.
- Remoção de bypasses de desenvolvimento.

#### [MODIFY] [demo-seed.sh](file:///Users/mauriciodesouza/Desktop/TRABALHO/GovAI%20-%20Enterprise%20AI%20GRC%20/GitHub%20/GovAIPlatform/scripts/demo-seed.sh)
- Sincronização do `password_hash` com a senha `"admin"`.
- Uso exclusivo do usuário `govai_app` para evitar falhas de permissão do superusuário.
- Implementação de `set -e` e export de `PGPASSWORD` para automação não-interativa.

### [DevOps] CI/CD Pipeline Restoration (Phase 2 Alignment)

#### [MODIFY] [ci-cd.yml](file:///Users/mauriciodesouza/Desktop/TRABALHO/GovAI%20-%20Enterprise%20AI%20GRC%20/GitHub%20/GovAIPlatform/.github/workflows/ci-cd.yml)
- **Restauração de Migrations**: Reativação do loop de execução para `init.sql` e migrations numéricas (`011` a `021`).
- **Unified DB Name**: Padronização para `govai_platform` em todos os steps.
- **Double-Strike SRE Override**: Contingência redundante para forçar o estado `requires_password_change = true` tanto no banco `govai` (legado) quanto no `govai_platform` (atual).
- **Reponisionamento de Healthcheck**: Validação da API reagendada para após o provisionamento completo do banco.

## Verification Plan

### Automated Tests
- Execução de `bash run_e2e_tests.sh` na esteira GitHub Actions.
- Verificação de logs do container `api` via `docker compose logs`.

### Manual Verification
- Validação do fluxo de "First Login" via interface Admin UI (padrão Rose/Emerald).
