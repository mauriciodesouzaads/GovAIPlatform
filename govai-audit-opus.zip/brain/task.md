# Task: Configuring Container Resource Limits
- [x] Define resource limits for the `presidio` service <!-- id: 0 -->
- [x] Create implementation plan <!-- id: 3 -->
- [x] Update `docker-compose.yml` with `deploy.resources.limits` <!-- id: 1 -->
- [x] Refinamento e Bugfix (Dashboard & UX) <!-- id: 60 -->
    - [x] [Backend] Implementar agregação SQL real para gráficos de estatísticas <!-- id: 61 -->
    - [x] [Frontend] Corrigir cálculo de Protection Rate e Status do Redis <!-- id: 62 -->
    - [x] [Frontend] Modal interativo de Versão em Assistants com API Real <!-- id: 63 -->
    - [x] [Frontend] Ações Reais em Approvals com Toasts Globais <!-- id: 64 -->
    - [x] [Design] Ajustar paleta de cores (Rose/Emerald) para padrão corporativo <!-- id: 65 -->

# Task: E2E Validation and Stability Check
- [x] Run `run_e2e_tests.sh` <!-- id: 4 -->
- [x] Analyze Phase 2 (Authentication/Password Reset) results & Fix 401/403 issues <!-- id: 5 -->
- [x] Analyze Phase 4 (Governance/DLP/OPA) results <!-- id: 6 -->
- [x] Stabilize and confirm project status <!-- id: 7 -->

# Task: Auditing Migration 017
- [x] Review `017_add_password_and_roles_to_users.sql` <!-- id: 8 -->
- [x] Optimize SQL for idempotency and security <!-- id: 9 -->
- [x] Provide corrected SQL block <!-- id: 10 -->

# Task: Tuning Redis Rate Limit
- [x] Analyze `src/server.ts` rate limit configuration <!-- id: 11 -->
- [x] Implement dynamic limits (1000 Auth / 50 Public) <!-- id: 12 -->
- [x] Add resilience (skipOnError, etc.) <!-- id: 13 -->
- [x] Provide updated TypeScript block <!-- id: 14 -->

# Task: Expanding Langfuse Observability
- [x] Update `telemetryQueue.add` in `src/server.ts` <!-- id: 15 -->
- [x] Update `src/workers/telemetry.worker.ts` to send prompt/completion to Langfuse <!-- id: 16 -->
- [x] Verify Langfuse integration <!-- id: 17 -->

# Task: Integrating Admin UI with Backend
- [x] Centralize API logic in `admin-ui/src/lib/api.ts` <!-- id: 18 -->
- [x] Update Dashboard components to use centralized `api` instance <!-- id: 19 -->
- [x] Update Approvals and Assistants pages <!-- id: 20 -->
- [x] Verify frontend rendering and data flow <!-- id: 21 -->

# Task: CI/CD & Cloud Preparation
- [x] Analyze Docker and E2E setup for CI/CD <!-- id: 22 -->
- [x] Create GitHub Actions workflow (`ci-cd.yml`) <!-- id: 23 -->
- [x] Document required secrets and setup steps <!-- id: 24 -->
- [x] Create `.dockerignore` files and optimize dependencies <!-- id: 25 -->

# Task: Sprint- [x] Ativação da UI e Monitoramento
    - [x] Implementar modal de publicação de versão em `assistants/page.tsx`
    - [x] Criar componente `HealthMonitor` no Dashboard
    - [x] Adicionar feedback visual (Sucesso/Erro) nas ações
    - [x] Validar integração E2E <!-- id: 40 -->
- [x] Finalização Frontend (Nível Produção)
    - [x] Gestão de Assistentes (Modal e POST)
    - [x] Gestão de Aprovações (HITL Real)
    - [x] Dashboard Bugfix (Math & Real Data)
    - [x] Refinamento Estético Corporativo (Palette Rose/Emerald)
    - [x] Notificações Toast para Ações Críticas
    - [x] Consistência Visual em Audit Logs
- [x] Automação DevOps e Deploy B2B <!-- id: 60 -->
    - [x] Script `push_github_secrets.sh` (Sync .env -> GitHub Secrets)
    - [x] Arquitetura de Produção `docker-compose.prod.yml`
    - [x] Refinamento de Pipeline CI/CD (Build & Push GHCR)
    - [x] [CI/CD] Injeção dinâmica de .env, Seeding e SRE Override (sed) <!-- id: 75 -->
    - [x] Configuração de Tags `:latest` e `${{ sha }}`
- [x] Refinement of Type and Linter (Frontend) <!-- id: 70 -->
    - [x] Cleanup of `any` in `login/page.tsx`
    - [x] Removal of unused imports in `assistants/page.tsx`
    - [x] Cleanup of unused states in `approvals/page.tsx`
    - [x] [reports/page.tsx] Remove `any` and fix unescaped quote <!-- id: 71 -->
    - [x] [page.tsx] Remove unused `useCallback` import <!-- id: 72 -->
    - [x] [assistants/page.tsx] Remove unused states and interface <!-- id: 73 -->
    - [x] [approvals/page.tsx] Add `toast` to `useCallback` dependency <!-- id: 74 -->
    - [x] Ações Reais (Aprovar/Rejeitar) na página de Approvals <!-- id: 53 -->
    - [x] Criar Card de "System Status" no Dashboard <!-- id: 54 -->
